<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_price_caches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_variant_id')->constrained('product_variants')->cascadeOnDelete();
            $table->string('role_code')->index();
            $table->decimal('final_price', 15, 2)->default(0);

            $table->timestamps();
            
            $table->index(['product_id', 'role_code']);
            $table->unique(['product_variant_id', 'role_code'], 'unique_variant_role_price');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_price_caches');
    }
};
