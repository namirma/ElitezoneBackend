<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('employer_consultant', function (Blueprint $table) {
            $table->string('reject_reason')->nullable()->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('employer_consultant', function (Blueprint $table) {
            $table->dropColumn('reject_reason');
        });
    }
};
