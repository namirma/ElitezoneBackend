<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\ProductVariant;
use App\Models\ProductPriceCache;
use App\Services\PriceCalculationService;
use Illuminate\Support\Facades\DB;

class CacheProductPrices extends Command
{
    protected $signature = 'products:cache-prices';
    protected $description = 'Calculate and cache product prices for all defined roles';

    const ROLES = [
        'employer_without_consultant',
        'engineer_with_consultant',
    ];

    public function handle(PriceCalculationService $priceService)
    {
        $this->info('Starting price calculation...');

        $variants = ProductVariant::with(['prices.factory', 'prices.factoryLocation'])
            ->where(ProductVariant::IS_ACTIVE, true)
            ->get();

        $bar = $this->output->createProgressBar($variants->count());
        $bar->start();

        foreach ($variants as $variant) {
            foreach (self::ROLES as $roleCode) {
                $minPrice = null;

                foreach ($variant->prices as $priceRecord) {
                    $calculated = $priceService->calculatePrice(
                        $variant,
                        $priceRecord->factory,
                        $priceRecord->factoryLocation,
                        null,
                        null,
                        null,
                        false,
                        $roleCode
                    );

                    $final = (float) $calculated['final_price'];

                    if (is_null($minPrice) || $final < $minPrice) {
                        $minPrice = $final;
                    }
                }

                if (!is_null($minPrice)) {
                    ProductPriceCache::updateOrCreate(
                        [
                            ProductPriceCache::PRODUCT_VARIANT_ID => $variant->id,
                            ProductPriceCache::ROLE_CODE          => $roleCode,
                        ],
                        [
                            ProductPriceCache::PRODUCT_ID  => $variant->product_id,
                            ProductPriceCache::FINAL_PRICE => $minPrice,
                        ]
                    );
                }
            }
            $bar->advance();
        }

        $bar->finish();
        $this->newLine();
        $this->info('Prices cached successfully.');
    }
}
