<?php

namespace App\Providers;

use App\Events\OrderCancelled;
use App\Events\OrderPaid;
use App\Events\OrderPlaced;
use App\Events\WalletFunded;
use App\Listeners\SendOrderCancellationNotification;
use App\Listeners\SendOrderPaymentNotification;
use App\Listeners\SendOrderPlacedNotification;
use App\Listeners\SendWalletFundingNotification;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event to listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
        OrderPaid::class => [
            SendOrderPaymentNotification::class,
        ],
        WalletFunded::class => [
            SendWalletFundingNotification::class,
        ],
        OrderCancelled::class => [
            SendOrderCancellationNotification::class,
        ],
        OrderPlaced::class => [
        SendOrderPlacedNotification::class,
    ],
    ];

    /**
     * Register any events for your application.
     */
    public function boot(): void
    {
        //
    }

    /**
     * Determine if events and listeners should be automatically discovered.
     */
    public function shouldDiscoverEvents(): bool
    {
        return false;
    }
}
