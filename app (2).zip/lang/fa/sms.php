<?php

return [
  'loginMessage' => 'پلتفرم EliteZone
  کد تایید:
  :code',

    'newRegisterUser' => '
    عرض سلام و ادب

   از ثبت نام شما سپاسگزاریم.

    در حال مذاکره با سوپلایر‌های محترم هستیم.
    برای قدم های بعدی به شما اطلاع رسانی خواهیم کرد.
    تیم EliteZone',
    "beneficiary_verification" => "کاربر :name قصد خرید به نام شما در الیت-زون را دارد. کد تایید: :code",
    'consultant_invitation' => 'کاربر :employer_name شما را به عنوان مشاور فنی در الیت-زون دعوت کرده است. لطفاً جهت تایید به پنل کاربری خود مراجعه کنید.',

    'transaction_confirmed' => 'کاربر گرامی، درخواست :type مبلغ :amount .ریال شما تایید شد',
    'transaction_rejected'  => 'کاربر گرامی، درخواست :type مبلغ :amount .ریال شما رد شد',

    'order_placed' => "سفارش شما با شماره :order_number رزرو شد.\nجهت تکمیل خرید، لطفاً پرداخت را انجام دهید.\nالیت زون",
];
