<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\Order;
use Illuminate\Support\Facades\Auth;

class OrderResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $user = Auth::user();
        $isSupplier = $user ? $user->hasRole('supplier') : false;

        $this->loadMissing(['items', 'placer.profile', 'beneficiary.profile', 'address.city', 'address.province']);

        $progress = $this->dashboard_progress ?? [];

        $statusKey = $this->{Order::STATUS};
        $statusLabel = __('orders.status.' . $statusKey);
        // Fallback for translation
        if ($statusLabel === 'orders.status.' . $statusKey) {
            $statusLabel = $progress['current_status_label'] ?? __('orders.status.unknown');
        }

        $paymentStatusKey = $this->{Order::PAYMENT_STATUS};
        $paymentStatusLabel = __('orders.status.' . $paymentStatusKey);
        if ($paymentStatusLabel === 'orders.status.' . $paymentStatusKey) {
            $paymentStatusLabel = $paymentStatusKey;
        }

        // Logic for action buttons
        $canPay = $paymentStatusKey !== Order::PAYMENT_PAID
            && $statusKey !== Order::STATUS_CANCELLED
            && $statusKey !== Order::STATUS_FAILED;

        $paymentUrl = $canPay ? route('api.user.orders.pay_full', ['order' => $this->id]) : null;
        $invoiceUrl = route('api.user.orders.invoice', ['order' => $this->id, 'type' => 'initial']);

        return [
            Order::ID           => $this->id,
            Order::ORDER_NUMBER => $this->{Order::ORDER_NUMBER},

            // --- Status Info ---
            'status_info' => [
                'key'   => $statusKey,
                'label' => $statusLabel,
                'color' => match ($statusKey) {
                    Order::STATUS_DELIVERED => 'success',
                    Order::STATUS_CANCELLED, Order::STATUS_FAILED => 'danger',
                    Order::STATUS_PENDING, Order::STATUS_RESERVED_EXTENDED => 'warning',
                    default => 'primary',
                },
                'progress_data' => $progress,
            ],

            // --- Items Summary (FIXED LOGIC) ---
            'items_summary' => $this->items->map(function ($item) {
                // 1. تلاش برای خواندن وزن/تعداد از ستون‌های دیتابیس (اگر موجود باشند)
                $val = (float) ($item->weight ?? 0);
                $unit = 'کیلوگرم';

                // 2. اگر ستون وزن خالی بود (چون در دیتابیس نیست)، سراغ جیسون می‌رویم
                if ($val <= 0 && !empty($item->quantity_details)) {
                    $details = is_string($item->quantity_details)
                        ? json_decode($item->quantity_details, true)
                        : $item->quantity_details;

                    // اگر جیسون معتبر بود (مثلا {"2": 8})
                    if (is_array($details) && count($details) > 0) {
                        // مقدار اول را می‌گیریم (عدد 8)
                        $val = (float) reset($details);
                        $unit = 'عدد'; // یا 'شاخه' / 'بندیل' بسته به نیاز بیزینس
                    }
                }

                // 3. اگر هنوز صفر بود، آخرین تلاش از ستون quantity
                if ($val <= 0) {
                    $val = (float) ($item->quantity ?? 0);
                }

                return [
                    'name'     => $item->product_variant->name ?? $item->product_name ?? 'محصول',
                    'quantity' => (string) $val,
                    'unit'     => $unit,
                ];
            }),

            // --- Buyer Info ---
            'buyer' => $this->when(!$isSupplier, function () {
                return [
                    'id'        => $this->{Order::PLACER_USER_ID},
                    'full_name' => $this->placer->full_name ?? 'کاربر ناشناس',
                    'mobile'    => $this->placer->mobile ?? null,
                ];
            }),

            // --- Beneficiary Info ---
            'beneficiary' => $this->when($this->{Order::BENEFICIARY_USER_ID}, function () {
                return [
                    'id'          => $this->{Order::BENEFICIARY_USER_ID},
                    'full_name'   => $this->beneficiary->full_name ?? 'نامشخص',
                    'national_id' => $this->beneficiary->profile->national_code ?? null,
                    'mobile'      => $this->beneficiary->mobile ?? null,
                ];
            }, null),

            // --- Financial Info ---
            'financial' => [
                Order::FINAL_AMOUNT    => (string) $this->{Order::FINAL_AMOUNT},
                Order::PAYMENT_STATUS  => $paymentStatusKey,
                'payment_status_text'  => $paymentStatusLabel,
                'is_paid'              => $paymentStatusKey === Order::PAYMENT_PAID,
                'paid_at_p'            => $this->{Order::PAID_AT} ? verta($this->{Order::PAID_AT})->format('Y/m/d H:i') : null,

                $this->mergeWhen(!$isSupplier, [
                    Order::SUBTOTAL        => (string) $this->{Order::SUBTOTAL},
                    Order::DISCOUNT_AMOUNT => (string) $this->{Order::DISCOUNT_AMOUNT},
                    Order::VAT_AMOUNT      => (string) $this->{Order::VAT_AMOUNT},
                    Order::SHIPPING_COST   => (string) $this->{Order::SHIPPING_COST},
                ]),
            ],

            // --- Address ---
            'delivery_address' => $this->when($this->address, function () {
                return [
                    'province'     => $this->address->province->name ?? '',
                    'city'         => $this->address->city->name ?? '',
                    'full_address' => $this->address->address,
                    'postal_code'  => $this->address->postal_code,
                    'receiver'     => $this->address->receiver_name,
                    'phone'        => $this->address->receiver_mobile,
                ];
            }),

            // --- Actions ---
            'actions' => [
                'download_invoice' => [
                    'label'  => __('orders.actions.download_initial_invoice'),
                    'url'    => $invoiceUrl,
                    'method' => 'GET',
                    'active' => true,
                ],
                'payment' => [
                    'label'  => __('orders.actions.final_invoice_settlement'),
                    'url'    => $paymentUrl,
                    'method' => 'POST',
                    'active' => !is_null($paymentUrl),
                ]
            ],

            // --- Dates ---
            'dates' => [
                'created_at_p'    => $this->created_at_p,
                'created_at_diff' => $this->created_at_diff,
            ],
        ];
    }
}
