<?php

namespace App\Actions\Order;

use App\Events\OrderPaid;
use App\Exceptions\Order\InvalidOrderStateException;
use App\Exceptions\Order\OrderNotPayableException;
use App\Exceptions\Wallet\InsufficientBalanceException;
use App\Models\Order;
use App\Models\User;
use App\Repositories\Contracts\OrderRepositoryInterface;
use Illuminate\Support\Facades\DB;
use Exception;

class PayOrderAction
{
    public function __construct(
        private readonly OrderRepositoryInterface $orderRepo
    ) {}

    /**
     * پردازش پرداخت سفارش
     *
     * @param User $user
     * @param Order $order
     * @param string $gateway
     * @return Order
     * @throws \App\Exceptions\BusinessException
     */
    public function execute(User $user, Order $order, string $gateway): Order
    {
        $payableStatuses = [Order::STATUS_PENDING, Order::STATUS_RESERVED_EXTENDED];

        if (!in_array($order->status, $payableStatuses)) {
            throw new OrderNotPayableException(__("orders.status.{$order->status}"));
        }

        // ۲. گارد: آیا قبلاً پرداخت شده؟
        if ($order->payment_status === Order::PAYMENT_PAID) {
            throw new InvalidOrderStateException('پرداخت شده', 'پرداخت مجدد');
        }

        // ۳. اجرای تراکنش اتمیک
        $updatedOrder = DB::transaction(function () use ($user, $order, $gateway) {

            // الف) کسر مبلغ (Logic Strategy)
            if ($gateway === 'wallet') {
                $this->payWithWallet($user, $order);
            } else {
                throw new Exception("درگاه $gateway هنوز پیاده‌سازی نشده است.");
            }

            $this->orderRepo->update($order, [
                Order::STATUS         => Order::STATUS_PROCESSING,
                Order::PAYMENT_STATUS => Order::PAYMENT_PAID,
                Order::PAYMENT_METHOD => $gateway,
                Order::PAID_AT        => now(),
            ]);

            return $order;
        });

        // ۴. شلیک رویداد
        OrderPaid::dispatch($updatedOrder);

        return $updatedOrder;
    }

    /**
     * منطق پرداخت با کیف پول
     */
    private function payWithWallet(User $user, Order $order): void
    {
        // بررسی موجودی
        if ($user->wallet_balance < $order->final_amount) {
            throw new InsufficientBalanceException();
        }

        // کسر موجودی
        $user->decrement('wallet_balance', $order->final_amount);

        // ثبت تراکنش مالی
        $user->walletTransactions()->create([
            'amount'         => -1 * $order->final_amount,
            'type'           => 'withdraw',
            'description'    => "پرداخت سفارش شماره {$order->order_number}",
            'meta'           => ['order_id' => $order->id],
            'balance_before' => $user->wallet_balance + $order->final_amount,
            'balance_after'  => $user->wallet_balance,
        ]);
    }
}
