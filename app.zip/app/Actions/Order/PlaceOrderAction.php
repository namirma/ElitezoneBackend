<?php

namespace App\Actions\Order;

use App\DataTransferObjects\PlaceOrderData;
use App\Events\OrderPlaced;
use App\Exceptions\Order\CartIsEmptyException;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\CustomerType;
use App\Models\Factory;
use App\Models\Offer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderUnit;
use App\Models\User;
use App\Models\UserType;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Services\InventoryService;
use App\Services\PriceCalculationService;
use App\Services\PricingRoleResolver;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Exception;

class PlaceOrderAction
{
    public function __construct(
        private readonly PriceCalculationService $priceService,
        private readonly PricingRoleResolver $roleResolver,
        private readonly InventoryService $inventoryService,
        private readonly OrderRepositoryInterface $orderRepo
    ) {}

    /**
     * اجرای عملیات ثبت سفارش
     *
     * @param User $user کاربر ثبت کننده سفارش
     * @param PlaceOrderData $data داده‌های ورودی (DTO)
     * @return Order سفارش ثبت شده
     * @throws Exception
     */
    public function execute(User $user, PlaceOrderData $data): Order
    {
        // ۱. دریافت و بررسی سبد خرید
        $cart = $this->getCartOrFail($user);

        // ۲. بررسی موجودی انبار (Fail Fast)
        $this->ensureStockIsAvailable($cart);

        // ۳. انجام تمام محاسبات مالی (قیمت‌ها، تخفیف‌ها، کارمزدها)
        $financials = $this->calculateFinancials($cart, $user, $data);

        // ۴. اجرای تراکنش دیتابیس
        return DB::transaction(function () use ($user, $cart, $data, $financials) {

            // 1. ایجاد سفارش
            $order = $this->createOrderRecord($user, $data, $financials);

            // 2. ثبت آیتم‌ها
            $this->createOrderItems($order, $cart);

            // 3. کسر موجودی (اینجا قفل اتفاق می‌افتد)
            // اگر در همین لحظه موجودی تمام شده باشد، اینجا Exception می‌دهد و کل تراکنش Rollback می‌شود
            $this->inventoryService->deductStockForOrder($order);

            // 4. حذف سبد خرید
            $this->clearCart($cart);

            return $order;
        });
    }

    // =========================================================================
    //  بخش ۱: دریافت و اعتبارسنجی
    // =========================================================================

    private function getCartOrFail(User $user): Cart
    {
        $cart = Cart::where(Cart::USER_ID, $user->id)
            ->with([
                'items.productVariant.product.offers',
                'items.factory',
                'items.factoryLocation',
                'customerType',
                'badge',
                'priceFilterCategories'
            ])->first();

        if (!$cart || $cart->items->isEmpty()) {
            // تغییر مهم
            throw new CartIsEmptyException();
        }

        return $cart;
    }

    private function ensureStockIsAvailable(Cart $cart): void
    {
        foreach ($cart->items as $item) {
            $requestedQty = array_sum($item->{CartItem::QUANTITIES} ?? []);
            if ($item->productVariant->stock_quantity < $requestedQty) {
                throw new Exception("موجودی محصول {$item->productVariant->name} کافی نیست.");
            }
        }
    }

    // =========================================================================
    //  بخش ۲: موتور محاسبات مالی
    // =========================================================================

    private function calculateFinancials(Cart $cart, User $user, PlaceOrderData $data): array
    {
        $subtotal = 0.0;
        $totalVat = 0.0;
        $totalItemDiscounts = 0.0;

        $activeCode = $this->roleResolver->resolve($user);
        $customerType = CustomerType::where(CustomerType::CODE, $activeCode)->first() ?: $cart->customerType;
        $orderUnitsMap = OrderUnit::all()->keyBy(OrderUnit::ID);

        // الف) محاسبه خط به خط آیتم‌ها
        foreach ($cart->items as $item) {
            /** @var \App\DataTransferObjects\Pricing\PriceCalculationResult $pricing */
            $pricing = $this->priceService->calculatePrice(
                variant: $item->productVariant,
                factory: $item->factory,
                location: $item->factoryLocation,
                customerType: $customerType,
                badge: $cart->badge,
                filterCategoryIds: null,
                withVAT: true
            );

            // محاسبه وزن کل آیتم
            $itemWeight = $this->calculateItemWeight($item->{CartItem::QUANTITIES}, $orderUnitsMap);

            $unitPrice = $pricing->finalPrice;
            $vatRate   = $pricing->vatRate;

            $lineTotal = $itemWeight * $unitPrice;
            $lineVat   = $lineTotal * ($vatRate / 100);

            // تزریق مقادیر محاسبه شده به مدل آیتم
            $item->calculated_unit_price = $unitPrice;
            $item->calculated_line_total = $lineTotal;

            // تجمیع مبالغ
            $subtotal += $lineTotal;
            $totalVat += $lineVat;

            // تجمیع تخفیف‌های واریانت
            $itemDiscountPerUnit = $pricing->variantDiscountAmount;
            $totalItemDiscounts += $itemDiscountPerUnit * $itemWeight;
        }

        // ب) محاسبه تخفیف‌های کلی (Offers)
        $cartOfferDiscount = $this->calculateCartLevelDiscounts($cart->items, $subtotal);
        $totalDiscount = $totalItemDiscounts + $cartOfferDiscount;

        // پ) محاسبه کارمزدها (Fees)
        $fees = $this->calculateBeneficiaryFees($user, $data->beneficiaryUserId, $subtotal);

        // ت) جمع‌بندی نهایی
        $shippingCost = 0.0;
        $finalAmount = ($subtotal - $cartOfferDiscount) + $totalVat + $shippingCost;

        return [
            'subtotal'       => $subtotal,
            'vat_amount'     => $totalVat,
            'total_discount' => $totalDiscount,
            'shipping_cost'  => $shippingCost,
            'final_amount'   => max(0, $finalAmount),
            'fees'           => $fees,
        ];
    }

    private function calculateItemWeight(array $quantities, Collection $unitsMap): float
    {
        $weight = 0.0;
        foreach ($quantities as $unitId => $qty) {
            if ($unit = $unitsMap->get($unitId)) {
                $weight += (float)$qty * (float)$unit->{OrderUnit::AMOUNT};
            }
        }
        return $weight;
    }

    private function calculateCartLevelDiscounts(Collection $items, float $subtotal): float
    {
        $applicableOffers = $items->flatMap(function (CartItem $item) {
            $qty = array_sum($item->{CartItem::QUANTITIES});
            return $item->productVariant->product->offers()->current()
                ->where(Offer::MINIMUM_QUANTITY, '<=', $qty)
                ->get();
        })->unique(Offer::ID);

        $discount = 0.0;
        foreach ($applicableOffers as $offer) {
            if ($offer->{Offer::TYPE} === 'percentage') {
                $discount += $subtotal * ($offer->{Offer::VALUE} / 100);
            } elseif ($offer->{Offer::TYPE} === 'fixed_amount') {
                $discount += (float)$offer->{Offer::VALUE};
            }
        }

        return min($discount, $subtotal);
    }

    private function calculateBeneficiaryFees(User $placer, ?int $beneficiaryId, float $subtotal): array
    {
        $fees = ['engineer' => null, 'contractor' => null];

        // اگر ذی‌نفع وجود ندارد یا خود کاربر است، کارمزدی تعلق نمی‌گیرد
        if (!$beneficiaryId || $beneficiaryId == $placer->id) {
            return $fees;
        }

        $beneficiary = User::find($beneficiaryId);
        if (!$beneficiary) return $fees;

        // دریافت آیدی تایپ‌ها (بهتر است کش شود)
        $typeIds = UserType::whereIn('slug', ['engineer', 'contractor'])
            ->pluck('id', 'slug');

        if (isset($typeIds['engineer']) && $beneficiary->{User::TYPE_ID} == $typeIds['engineer']) {
            $pct = config('elitezon.consultant_fee_percentage', 2.0);
            $fees['engineer'] = ($subtotal * $pct) / 100;
        } elseif (isset($typeIds['contractor']) && $beneficiary->{User::TYPE_ID} == $typeIds['contractor']) {
            $pct = config('elitezon.contractor_fee_percentage', 2.0);
            $fees['contractor'] = ($subtotal * $pct) / 100;
        }

        return $fees;
    }

    // =========================================================================
    //  بخش ۳: عملیات دیتابیس
    // =========================================================================

    private function createOrderRecord(User $user, PlaceOrderData $data, array $fins): Order
    {
        // به جای Order::create مستقیماً، از متد create ریپازیتوری استفاده می‌کنیم.
        // داده‌ها را به صورت آرایه پاس می‌دهیم (طبق تعریف اینترفیس)
        return $this->orderRepo->create([
            Order::PLACER_USER_ID         => $user->id,
            Order::BENEFICIARY_USER_ID    => $data->beneficiaryUserId ?? $user->id,
            Order::ADDRESS_ID             => $data->addressId,
            Order::ORDER_NUMBER           => 'EL-' . strtoupper(Str::random(10)),

            Order::STATUS                 => Order::STATUS_PENDING,
            Order::PAYMENT_STATUS         => Order::PAYMENT_PENDING,

            Order::SUBTOTAL               => $fins['subtotal'],
            Order::DISCOUNT_AMOUNT        => $fins['total_discount'],
            Order::VAT_AMOUNT             => $fins['vat_amount'],
            Order::SHIPPING_COST          => $fins['shipping_cost'],
            Order::FINAL_AMOUNT           => $fins['final_amount'],

            Order::ENGINEER_FEE_AMOUNT    => $fins['fees']['engineer'],
            Order::CONTRACTOR_FEE_AMOUNT  => $fins['fees']['contractor'],
            Order::ENGINEER_FEE_PAYMENT_STATUS => $fins['fees']['engineer'] ? Order::FEE_PAYMENT_PENDING : null,
            Order::CONTRACTOR_FEE_PAYMENT_STATUS => $fins['fees']['contractor'] ? Order::FEE_PAYMENT_PENDING : null,

            Order::RESERVATION_EXPIRES_AT => now()->addHours(2),
            Order::NOTES                  => $data->description,
        ]);
    }

    private function createOrderItems(Order $order, Cart $cart): void
    {
        foreach ($cart->items as $item) {
            $supplierId = $item->factory->{Factory::SUPPLIER_USER_ID} ?? null;

            if (!$supplierId) {
                // اگر تامین کننده پیدا نشد، بهتر است لاگ شود یا خطای مشخص‌تری پرتاب شود
                throw new Exception("تامین‌کننده برای کارخانه {$item->factory->name} تعریف نشده است.");
            }

            OrderItem::create([
                OrderItem::ORDER_ID           => $order->id,
                OrderItem::PRODUCT_VARIANT_ID => $item->{CartItem::PRODUCT_VARIANT_ID},
                OrderItem::SUPPLIER_USER_ID   => $supplierId,

                // کپی کردن نام و SKU برای تاریخچه (Snapshot)
                OrderItem::PRODUCT_NAME       => $item->productVariant->{\App\Models\ProductVariant::NAME},
                OrderItem::VARIANT_SKU        => $item->productVariant->{\App\Models\ProductVariant::SKU},

                OrderItem::QUANTITY_DETAILS   => $item->{CartItem::QUANTITIES},
                OrderItem::UNIT_PRICE         => $item->calculated_unit_price, // از مقادیر محاسبه شده
                OrderItem::TOTAL_PRICE        => $item->calculated_line_total,
            ]);
        }
    }

    private function clearCart(Cart $cart): void
    {
        $cart->items()->delete();
        $cart->delete();
    }
}
