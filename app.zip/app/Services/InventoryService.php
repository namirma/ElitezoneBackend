<?php

namespace App\Services;

use App\Exceptions\Order\StockUnavailableException;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\ProductVariant;
use Exception;
use Illuminate\Support\Collection;

class InventoryService
{
    /**
     * کسر موجودی به صورت امن (Thread-Safe)
     * این متد باید حتماً داخل یک DB::transaction صدا زده شود.
     */
    public function deductStockForOrder(Order $order): void
    {
        // دریافت تمام واریانت‌های درگیر در سفارش
        $order->load('items');

        foreach ($order->items as $item) {
            $this->deductItemStock($item);
        }
    }

    /**
     * رزرو و کسر موجودی یک آیتم با قفل کردن ردیف دیتابیس
     */
    private function deductItemStock(OrderItem $item): void
    {
        // 1. پیدا کردن واریانت و قفل کردن آن برای نوشتن
        $variant = ProductVariant::where('id', $item->product_variant_id)
            ->lockForUpdate()
            ->first();

        if (!$variant) {
            throw new Exception("محصول با شناسه {$item->product_variant_id} یافت نشد.");
        }

        // 2. محاسبه تعداد مورد نیاز (جمع مقادیر مختلف واحدهای سفارش)
        $requiredQty = $this->calculateTotalQuantity($item->quantity_details);

        // 3. چک کردن موجودی واقعی (بعد از قفل شدن)
        if ($variant->stock_quantity < $requiredQty) {
            // تغییر مهم: پرتاب اکسپشن اختصاصی
            throw new StockUnavailableException($variant->name);
        }

        $variant->decrement('stock_quantity', $requiredQty);
    }

    /**
     * بازگرداندن موجودی (در صورت لغو سفارش)
     */
    public function restoreStock(Order $order): void
    {
        foreach ($order->items as $item) {
            $qty = $this->calculateTotalQuantity($item->quantity_details);

            ProductVariant::where('id', $item->product_variant_id)
                ->increment('stock_quantity', $qty);
        }
    }

    /**
     * محاسبه تعداد کل از روی آرایه جزئیات
     */
    private function calculateTotalQuantity(?array $details): float
    {
        if (empty($details)) return 0;
        return (float) array_sum($details);
    }
}
